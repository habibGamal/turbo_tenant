function n(t){return!t||typeof t!="string"||!t.startsWith("/")||t.startsWith("//")||t.startsWith("/\\")||t.includes("\\")||/[\x00-\x1F\x7F]/.test(t)?"/":t}export{n as g};
